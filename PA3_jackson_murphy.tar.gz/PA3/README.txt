Author: Jackson Murphy
Last Updated: October 25, 2017

University Of Utah Natural Language Processing Assignment 3

How to run the code:

  $ python3.6 train.txt test.txt locs.txt <feature types>

This program was tested on CADE machine "lab1-17"

There are no known problems with this program.
